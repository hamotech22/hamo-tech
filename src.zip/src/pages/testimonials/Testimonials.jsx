import useLanguage from "../../context/useLanguage";

export default function Testimonials() {
  const { t } = useLanguage();
  return (
    <section className="bg-zinc-100 px-5 py-20 sm:py-28 md:px-10" data-aos="fade-up">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-12 max-w-2xl sm:mb-16" data-aos="fade-up">
          <h2 className="text-balance bg-linear-to-b from-zinc-950 to-zinc-600 bg-clip-text text-4xl font-semibold leading-[1.1] tracking-tight text-transparent sm:text-5xl">
            {t.testimonials.title}
          </h2>

          <p className="mt-5 max-w-xl text-pretty text-base leading-7 text-zinc-600 sm:text-lg sm:leading-8">
            {t.testimonials.description}
          </p>
        </div>

        {/* Testimonial cards */}
        <div className="grid gap-5 md:grid-cols-3">
          {t.testimonials.roles.map((role, index) => (
            <article
              key={role}
              className="group flex flex-col rounded-3xl bg-white p-7 shadow-sm ring-1 ring-zinc-900/5 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-zinc-900/5"
              data-aos="fade-up"
            >
              <h3 className="text-lg font-semibold text-zinc-950">{role}</h3>
              <p className="mt-4 text-pretty text-base leading-7 text-zinc-600 sm:text-lg sm:leading-8">
                {t.testimonials.quotes[index]}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
